package com.sf.codingcomp.tweet;

public class TweetTooLongException extends Exception {

	private static final long serialVersionUID = 1901373282111896057L;

}
