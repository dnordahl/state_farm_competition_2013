package com.sf.codingcomp.duck;

public class Duck {

}
