package com.sf.codingcomp.security;

public class RoleAlreadyExistsException extends Exception {

	private static final long serialVersionUID = -7939216801969365863L;

}
