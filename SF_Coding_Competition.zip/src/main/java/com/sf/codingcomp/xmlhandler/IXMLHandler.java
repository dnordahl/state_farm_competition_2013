package com.sf.codingcomp.xmlhandler;



public interface IXMLHandler {
	String toXML(Input inputParameter);
	Output fromXML(String output);
	
}
