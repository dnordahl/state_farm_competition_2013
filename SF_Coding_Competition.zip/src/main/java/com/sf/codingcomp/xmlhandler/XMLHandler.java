package com.sf.codingcomp.xmlhandler;

public class XMLHandler implements IXMLHandler {

	public String toXML(Input inputParameter) {
		// TODO implement me
		return null;
	}

	public Output fromXML(String outputParameter) {
		// TODO implement me
		return null;
	}

}
