package com.sf.codingcomp.arena;

public class NoStaminaException extends Exception {

	private static final long serialVersionUID = 4670614858690098474L;

}
