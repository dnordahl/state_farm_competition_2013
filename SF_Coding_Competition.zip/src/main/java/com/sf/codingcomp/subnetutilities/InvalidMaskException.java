package com.sf.codingcomp.subnetutilities;

//
//Do not change anything in the following JAVA class!
//
public class InvalidMaskException extends Exception {
	private static final long serialVersionUID = -8839951888336555646L;
}
