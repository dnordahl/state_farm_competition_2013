package com.sf.codingcomp.football;

public class TooManyPlayersException extends Exception {

	private static final long serialVersionUID = -8533568023049221427L;

}
